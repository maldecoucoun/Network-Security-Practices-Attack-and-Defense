<?php
/**
 * Template Name: Full Width Template
 *
 * The template for displaying a full width page.
 *
 * @package zues
 */

zues();
