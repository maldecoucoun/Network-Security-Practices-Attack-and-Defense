<?php
/**
 * Footer Name: Example
 *
 * An example footer for our theme.
 *
 * @package zues
 */
